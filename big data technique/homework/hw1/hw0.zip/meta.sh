for file in p[0-9]*.sh;
do
  time $file
  bash $file
done
mkdir Output
mv *.txt Output
